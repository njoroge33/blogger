// Exports the "emoticons" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/emoticons')
//   ES2015:
//     import 'tinymce/plugins/emoticons'
require('./plugin.js');